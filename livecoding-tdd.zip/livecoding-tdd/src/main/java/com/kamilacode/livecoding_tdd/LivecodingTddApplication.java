package com.kamilacode.livecoding_tdd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LivecodingTddApplication {

	public static void main(String[] args) {
		SpringApplication.run(LivecodingTddApplication.class, args);
	}

}
