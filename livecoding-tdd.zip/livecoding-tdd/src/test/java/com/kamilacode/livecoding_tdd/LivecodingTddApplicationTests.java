package com.kamilacode.livecoding_tdd;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LivecodingTddApplicationTests {

	@Test
	void contextLoads() {
	}

}
